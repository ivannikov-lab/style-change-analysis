import re
from preprocess_NLP_pkg.load_data import read_file
import nltk

def read_most_common_connectors_en():
    connectors_path = "data/connectors.csv"
    f = open(connectors_path, 'r', encoding = 'utf-8-sig')
    file_content = f.read().strip()
    connectors = re.split("[\\n]+", file_content)
    #connectors = []
    #for line in lines:
    #    words = line.split(",")
    #    connectors.append(words)
    return connectors


def get_feature_vectors(text):
    lower_text = text.lower()
    tokens = nltk.tokenize.word_tokenize(lower_text)
    connectors = read_most_common_connectors_en()
    feature_vector = []
    for connector in connectors:
        token_count = len(re.findall(connector, lower_text))
        feature_vector.append(token_count)
    feature_vector = [val/len(tokens) for val in feature_vector]
    return feature_vector
