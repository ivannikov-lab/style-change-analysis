
import unittest
from preprocess_NLP_pkg.text_processing import *


class TestTokenize(unittest.TestCase):

    def test_tokenize(self):
        pass



class TestRemoveNonAscii(unittest.TestCase):

    def test_remove_non_ascii(self):
        pass



class TestToLowercase(unittest.TestCase):

    def test_to_lowercase(self):
        pass



class TestRemovePunctuation(unittest.TestCase):

    def test_remove_punctuation(self):
        pass


class TestReplaceNumbers(unittest.TestCase):

    def test_replace_numbers(self):
        pass


class TestRemoveStopword_list(unittest.TestCase):

    def test_remove_stopword_list(self):
        pass


class TestStemword_list(unittest.TestCase):

    def test_stem_word_list(self):
        pass


class TestLemmatizeVerbs(unittest.TestCase):

    def test_lemmatize_verbs(self):
        pass


class TestNormalize(unittest.TestCase):

    def test_normalize(self):
        pass


class TestStemAndLemmatize(unittest.TestCase):

    def test_stem_and_lemmatize(self):
        pass

