import  unittest
from preprocess_NLP_pkg.load_data import *


class TestReadFile(unittest.TestCase):
    def test_read_file(self):
        pass


class TestReadCompressedLzmaFile(unittest.TestCase):
    def test_(self):
        pass


class TestWriteFile(unittest.TestCase):
    def test_write_file(self):
        pass