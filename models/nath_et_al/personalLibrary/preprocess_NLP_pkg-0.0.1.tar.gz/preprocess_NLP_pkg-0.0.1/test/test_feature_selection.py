import unittest
from preprocess_NLP_pkg.feature_selection import *


class TestConvertDictToNumpyArray(unittest.TestCase):
    def test_convert_dict_to_numpy_array(self):
        pass


class TestSelectFeatures(unittest.TestCase):
    def test_select_features(self):
        pass


class TestMaxWordLength(unittest.TestCase):
    def test_max_word_length(self):
        pass


class TestAverageWordLength(unittest.TestCase):
    def test_average_word_length(self):
        pass


class TestMaxSentenceLength(unittest.TestCase):
    def test_max_sentence_length(self):
        pass


class TestAverageSentenceLength(unittest.TestCase):
    def test_average_sentence_length(self):
        pass


class TestYulesK(unittest.TestCase):
    def test_yules_K(self):
        pass


class TestTTR(unittest.TestCase):
    def test_TTR(self):
        pass


class TestWordFreqCount(unittest.TestCase):
    def test_word_freq_count(self):
        pass


class TestSelectWordVector(unittest.TestCase):
    def test_select_word_vector(self):
        pass


class TestWordFreqCountNormalised(unittest.TestCase):
    def test_word_freq_count_normalised(self):
        pass


class TestCharNgramFreq(unittest.TestCase):
    def test_char_ngram_freq(self):
        pass


class TestMostCommonNgrams(unittest.TestCase):
    def test_(self):
        pass
