import unittest
from preprocess_NLP_pkg.corpus_processor import *


class TestAuthorDictionary(unittest.TestCase):

    def test_author_dictionary(self):
        pass


class TestAuthorDictionaryItalian(unittest.TestCase):

    def test_(self):
        pass


class TestMostCommonword_listFromFile(unittest.TestCase):

    def test_most_common_word_list_from_file(self):
        pass


class TestMostCommonword_listFromCorpus(unittest.TestCase):

    def test_most_common_word_list_from_corpus(self):
        pass